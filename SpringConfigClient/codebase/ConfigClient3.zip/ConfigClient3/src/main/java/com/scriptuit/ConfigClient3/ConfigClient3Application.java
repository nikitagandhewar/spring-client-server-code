package com.scriptuit.ConfigClient3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigClient3Application {

	public static void main(String[] args) {
		SpringApplication.run(ConfigClient3Application.class, args);
	}
}
